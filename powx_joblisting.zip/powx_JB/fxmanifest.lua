----------------------------------------------
----------------------------------------------
--Pole Emploit Cree avec le PMenu By PowX#2629
----------------------------------------------
----------------------------------------------


fx_version 'adamant'

game 'gta5'

client_scripts {
	'cl_powx.lua',
	'framework.lua'
}

server_scripts {
	'srv_powx.lua'
}

dependency 'es_extended'